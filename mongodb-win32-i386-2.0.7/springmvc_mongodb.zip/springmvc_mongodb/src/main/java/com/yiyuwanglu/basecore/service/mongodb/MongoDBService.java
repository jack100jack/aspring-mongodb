package com.yiyuwanglu.basecore.service.mongodb;

public class MongoDBService {

}
