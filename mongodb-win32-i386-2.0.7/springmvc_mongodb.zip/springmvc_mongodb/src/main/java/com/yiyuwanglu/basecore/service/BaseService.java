package com.yiyuwanglu.basecore.service;

public interface BaseService {

}
